package com.mytest;

import static org.junit.Assert.*;

import org.junit.Test;

public class NumberGuessTest {

	@Test
	public void testMain() {
		
		NumberGuess.main(new String[] {"arg1", "arg2", "arg3"});
		assertTrue( true );
	}

}
