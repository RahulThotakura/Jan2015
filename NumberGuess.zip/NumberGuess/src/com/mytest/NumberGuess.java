package com.mytest;

import java.util.*;

public class NumberGuess {

	/**
	 * Author: Rahul S. Thotakura Date: 01/06/2015
	 * 
	 */

	public static void main(String[] args) {

		Scanner scr = new Scanner(System.in);
		int max = 100;
		int current = 0;
		int attempts = 0;
		int low = 1;
		int high = max;

		System.out
		.println("Hello. Are you ready to play?.If you are ready, go ahead and type in: ready");
		
		String input = scr.next();

		if (input != null && input.equalsIgnoreCase("ready")) {
			
			
			
			
			if (input.equalsIgnoreCase("end")) {
				System.out.println("You chose to end the game. Exiting now!");
				return;
			}

				do {
					current = (low + high) / 2;
					++attempts;
					
					System.out.println("Is the number " + current);
					input = scr.next();

					if (input.equalsIgnoreCase("lower")) {
						high = current - 1;
						continue;
					}

					if (input.equalsIgnoreCase("higher")) {
						low = current + 1;
						continue;
					}

				} while (!input.equalsIgnoreCase("end")
						&& !input.equalsIgnoreCase("yes"));

			
			 if (input.equalsIgnoreCase("yes")) {
				System.out
						.println("You have guessed the number successfully in "
								+ attempts +" attempts");
				return;

			}
		} else {

			System.out
					.println("You indicated that you are not ready.Exiting Now...");
		}
	}
}
